#ifndef _LINUX_MPLS_H
#define _LINUX_MPLS_H

#include <uapi/linux/mpls.h>

#endif  /* _LINUX_MPLS_H */
